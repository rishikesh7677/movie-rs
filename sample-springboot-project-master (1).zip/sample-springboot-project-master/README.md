# sample-springboot-project

Sample springboot project for HU CI pipeline testing