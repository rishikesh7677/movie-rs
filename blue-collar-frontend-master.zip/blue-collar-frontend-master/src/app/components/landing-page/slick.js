$(document).ready(function(){

    $('.slider').slick({
        arrows:true
    })

});