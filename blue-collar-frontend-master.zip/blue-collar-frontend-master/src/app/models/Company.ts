export class Company {
    "companyName":string;
    "email":string;
    "password":string;
    "country":string;
  }
  