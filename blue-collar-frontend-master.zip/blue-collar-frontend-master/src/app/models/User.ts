export class User {
  "name":string;
  "email":string;
  "phonenumber":string;
  "password":string;
}
