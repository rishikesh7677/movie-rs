import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.scss']
})
export class UserprofileComponent implements OnInit {
  showWindow=0;
  userDetails:{
    id: string ,
    displayName: string,
    firstName: string,
    lastName: string,
    aboutYourself :string,
    areasOfInterest:[number],
    experience: string,
    expertise: string,
    isProfessional:boolean ,
    roleText: string,
    status: string
  };
  interests = ['Designer','Developer','React','Java']
  experience = ['0-5','5-10','10 & Above']
  expertise = ['React','Java','Backend']

  userProfile: FormGroup;

  courseService: CourseService;
  subscription;

  constructor(courseService: CourseService) {
    this.courseService = courseService;
  }


  ngOnInit(): void {
    this.userProfile = new FormGroup({
      'displayName' : new FormControl(null, Validators.required),
      'firstName' : new FormControl(null, Validators.required),
      'lastName' : new FormControl(null),
      'about' : new FormControl(null,Validators.maxLength(100)),
      'interests' : new FormControl(),
      'role' : new FormControl('Professional'),
      'experience' : new FormControl(),
      'expertise' : new FormControl(),
      'mentionyourRole' : new FormControl(null,Validators.maxLength(200)),
    });
    this.courseService.fetchUser();
    this.subscription = this.courseService.userDetailsUpdated.subscribe(
      ()=>{
          this.userDetails = this.courseService.getUser();
          console.log(this.userDetails);
          this.userProfile.setValue({
            'displayName' : this.userDetails.displayName,
            'firstName' : this.userDetails.firstName,
            'lastName' : this.userDetails.lastName,
            'about' : this.userDetails.aboutYourself,
            'interests' : '',
            'role' : this.userDetails.isProfessional? 'Professional':'Student',
            'experience' : this.userDetails.experience,
            'expertise' : this.userDetails.experience,
            'mentionyourRole' : this.userDetails.roleText,
          });
      }
    );
  }

  onSubmit(){
    console.log(this.userProfile.value);
    alert('User Values Updated')
    let response = {
      "firstName": this.userProfile.value.firstName,
      "displayName": this.userProfile.value.displayName,
      "roleText": this.userProfile.value.mentionyourRole,
      "aboutYourself": this.userProfile.value.about,
      "lastName": this.userProfile.value.lastName,
    }
    this.courseService.updateUserDetails(response);
    console.log('click')
  }

  details(val){
    this.showWindow=val;
  }

}
