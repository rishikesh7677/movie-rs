import { Component , OnInit} from '@angular/core';
import { CourseService } from './course.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title = 'HUv19Assignment';

  courseService : CourseService
  constructor(courseService : CourseService){
    this.courseService=courseService;
  }

  ngOnInit(){
    this.courseService.fetchCourses();
  }

}
