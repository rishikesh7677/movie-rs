import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SecondHeaderComponent } from './second-header/second-header.component';
import { MainDashboardComponent } from './main-dashboard/main-dashboard.component';
import { CourseService } from './course.service';
import { CourseDetailsComponent } from './course-details/course-details.component';
import { YourCartDetailsComponent } from './your-cart-details/your-cart-details.component';
import { CheckoutDashboardComponent } from './checkout-dashboard/checkout-dashboard.component';
import { CartCourseDetailsComponent } from './cart-course-details/cart-course-details.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { CartInformationComponent } from './cart-information/cart-information.component';
import { WishlistCourseDetailsComponent } from './wishlist-course-details/wishlist-course-details.component';
import { CourseMoreDetailsComponent } from './course-more-details/course-more-details.component';

@NgModule({
  declarations: [
    AppComponent,
    SecondHeaderComponent,
    MainDashboardComponent,
    CourseDetailsComponent,
    YourCartDetailsComponent,
    CheckoutDashboardComponent,
    CartCourseDetailsComponent,
    WishlistComponent,
    UserprofileComponent,
    CartInformationComponent,
    WishlistCourseDetailsComponent,
    CourseMoreDetailsComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule

  ],
  providers: [CourseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
