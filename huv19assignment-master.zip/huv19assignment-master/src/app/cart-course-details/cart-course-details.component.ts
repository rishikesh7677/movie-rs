import { Component, OnInit,Input } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-cart-course-details',
  templateUrl: './cart-course-details.component.html',
  styleUrls: ['./cart-course-details.component.scss']
})
export class CartCourseDetailsComponent implements OnInit {
  @Input() course_detail;

  courseService: CourseService
  constructor(courseService: CourseService) {
    this.courseService = courseService;
  }

  ngOnInit(): void {
  }

  removeFromCart(){
    console.log('Remove cart')
    this.courseService.changeStatusOfCourse_DeleteAddedToCart(this.course_detail);
    // this.courseService.removeFromCart(this.course_detail);
  }


  addToWishlist(){
    console.log('ADD');
    this.courseService.changeStatusOfCourse_Wishlisted(this.course_detail);
    // this.courseService.addToWishlist(this.course_detail);
  }

  removeFromWishlist(){
    console.log('REMOVE')
    this.courseService.changeStatusOfCourse_DeleteWishList(this.course_detail);
    // this.courseService.removeFromWishlist(this.course_detail);
  }

}
