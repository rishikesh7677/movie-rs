import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CartCourseDetailsComponent } from './cart-course-details.component';

describe('CartCourseDetailsComponent', () => {
  let component: CartCourseDetailsComponent;
  let fixture: ComponentFixture<CartCourseDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CartCourseDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CartCourseDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
