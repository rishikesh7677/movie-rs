import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.scss']
})
export class WishlistComponent implements OnInit {
  wishListCourses = [];
  courseService: CourseService;
  subscription;
  constructor(courseService: CourseService) {
    this.courseService = courseService;
  }

  ngOnInit(): void {
    this.wishListCourses = this.courseService.getWishListCourses();

    this.subscription = this.courseService.cartUpdated.subscribe(
      ()=>{
        this.wishListCourses = this.courseService.getWishListCourses();
      }
    );

  }

}
