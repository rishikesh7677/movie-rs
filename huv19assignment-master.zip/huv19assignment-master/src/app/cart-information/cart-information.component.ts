import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-cart-information',
  templateUrl: './cart-information.component.html',
  styleUrls: ['./cart-information.component.scss']
})
export class CartInformationComponent implements OnInit {

  allCourses = [];
  boughtCourses = [];
  totalCost=0;

  courseService: CourseService;
  subscription;

  constructor(courseService: CourseService) {
    this.courseService = courseService;
  }

  ngOnInit(): void {
    this.allCourses = this.courseService.getAllCourses();
    this.boughtCourses = this.courseService.getAllBoughtCourses();
    this.totalCost =this.courseService.getCost();

    this.subscription = this.courseService.cartUpdated.subscribe(
      ()=>{
        this.allCourses = this.courseService.getAllCourses();
        this.boughtCourses = this.courseService.getAllBoughtCourses();
        this.totalCost =this.courseService.getCost();
      }
    );

  }

}
