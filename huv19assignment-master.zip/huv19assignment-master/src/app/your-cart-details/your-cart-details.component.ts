import { Component, OnInit ,Input} from '@angular/core';

@Component({
  selector: 'app-your-cart-details',
  templateUrl: './your-cart-details.component.html',
  styleUrls: ['./your-cart-details.component.scss']
})
export class YourCartDetailsComponent implements OnInit {
  @Input() course_detail;
  constructor() { }

  ngOnInit(): void {
  }

}
