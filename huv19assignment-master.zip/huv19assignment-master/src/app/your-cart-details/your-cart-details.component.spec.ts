import { ComponentFixture, TestBed } from '@angular/core/testing';

import { YourCartDetailsComponent } from './your-cart-details.component';

describe('YourCartDetailsComponent', () => {
  let component: YourCartDetailsComponent;
  let fixture: ComponentFixture<YourCartDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ YourCartDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(YourCartDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
