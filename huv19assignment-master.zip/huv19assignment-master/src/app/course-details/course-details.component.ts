import { Component, Input, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-course-details',
  templateUrl: './course-details.component.html',
  styleUrls: ['./course-details.component.scss']
})
export class CourseDetailsComponent implements OnInit {
  @Input() course_detail;

  courseService: CourseService
  constructor(courseService: CourseService) {
    this.courseService = courseService;
  }

  ngOnInit(): void {
  }

  addToCart(){
    console.log('ADD to cart')
    this.courseService.changeStatusOfCourse_AddedtoCart(this.course_detail);
    // this.courseService.addToCart(this.course_detail);
  }

  removeFromCart(){
    console.log('Remove cart');
    this.courseService.changeStatusOfCourse_DeleteAddedToCart(this.course_detail);
    // this.courseService.removeFromCart(this.course_detail);
  }

  addToWishlist(){
    console.log('ADD');
    this.courseService.changeStatusOfCourse_Wishlisted(this.course_detail);
    // this.courseService.addToWishlist(this.course_detail);
  }

  removeFromWishlist(){
    console.log('REMOVE')
    this.courseService.changeStatusOfCourse_DeleteWishList(this.course_detail);
    // this.courseService.removeFromWishlist(this.course_detail);
  }

}
