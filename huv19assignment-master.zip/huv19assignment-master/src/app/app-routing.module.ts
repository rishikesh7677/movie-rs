import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { MainDashboardComponent } from './main-dashboard/main-dashboard.component';
import { CheckoutDashboardComponent } from './checkout-dashboard/checkout-dashboard.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { CourseMoreDetailsComponent } from './course-more-details/course-more-details.component';

const routes = [
  {path :'course/:side',component: CourseMoreDetailsComponent},
  {path :'',component: MainDashboardComponent},
  {path :'checkout',component: CheckoutDashboardComponent},
  {path :'wishlist',component: WishlistComponent},
  {path :'userprofile',component: UserprofileComponent},
  {path :'**',redirectTo :'/'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
