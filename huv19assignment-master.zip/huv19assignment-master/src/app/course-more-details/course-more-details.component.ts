import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-course-more-details',
  templateUrl: './course-more-details.component.html',
  styleUrls: ['./course-more-details.component.scss']
})
export class CourseMoreDetailsComponent implements OnInit {
  courseId;
  course_detail:{
    id: string ,
    title :string,
    courseCreator:string,
    courseDescription: string,
    discount: number,
    price:number ,
    tags: [string],
    status: string
  };
  activatedRoute : ActivatedRoute;
  courseService : CourseService;
  loadedSide = 'all';
  subscription;

  constructor(activatedRoute : ActivatedRoute,courseService : CourseService) {
    this.activatedRoute = activatedRoute;
    this.courseService = courseService;
  }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(
      (params)=>{
        this.courseId = params.side;
        console.log(params.side);
      }
    );
    this.courseService.fetchSingleCourse(this.courseId);
    this.subscription = this.courseService.singleCourseDetailsUpdated.subscribe(
      ()=>{
          this.course_detail = this.courseService.getSingleCourse();
          console.log(this.course_detail);
          console.log(this.course_detail.status);
          console.log('This is Course Details');
      }
    );
  }

  addToCart(){
    console.log('ADD to cart')
    this.courseService.changeStatusOfCourse_AddedtoCart(this.course_detail);
    // this.courseService.addToCart(this.course_detail);
  }

  removeFromCart(){
    console.log('Remove cart');
    this.courseService.changeStatusOfCourse_DeleteAddedToCart(this.course_detail);
    // this.courseService.removeFromCart(this.course_detail);
  }

  addToWishlist(){
    console.log('ADD');
    this.courseService.changeStatusOfCourse_Wishlisted(this.course_detail);
    // this.courseService.addToWishlist(this.course_detail);
  }

  removeFromWishlist(){
    console.log('REMOVE')
    this.courseService.changeStatusOfCourse_DeleteWishList(this.course_detail);
    // this.courseService.removeFromWishlist(this.course_detail);
  }

}
