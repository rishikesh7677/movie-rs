import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wishlist-course-details',
  templateUrl: './wishlist-course-details.component.html',
  styleUrls: ['./wishlist-course-details.component.scss']
})
export class WishlistCourseDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
