import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WishlistCourseDetailsComponent } from './wishlist-course-details.component';

describe('WishlistCourseDetailsComponent', () => {
  let component: WishlistCourseDetailsComponent;
  let fixture: ComponentFixture<WishlistCourseDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WishlistCourseDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WishlistCourseDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
