import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { HttpClient } from '@angular/common/http'
import { map } from 'rxjs/operators';

@Injectable()
export class CourseService{

  private totalCost = 0;
  private allCourses = [
    {id: 'dhruv' , title :'Python title',course_creator:'Dhruv Bansal', price:100 ,wishlist: false, boughtState: false },
    {id: 'daksj' , title :'CSS title',course_creator:'Dhruv Bansal', price:100 ,wishlist: false, boughtState: false },
    {id: 'pops' , title :'HTML title',course_creator:'Dhruv Bansal', price:100 ,wishlist: false, boughtState: false },
    {id: 'b1' , title :'java title',course_creator:'Dhruv Bansal', price:100 ,wishlist: false, boughtState: false },
    {id: 'b2' , title :'react title',course_creator:'Dhruv Bansal', price:100 ,wishlist: false, boughtState: false },
  ];

  private userDetails:{
    id: string ,
    displayName: string,
    firstName: string,
    lastName: string,
    aboutYourself :string,
    areasOfInterest:[number],
    experience: string,
    expertise: string,
    isProfessional:boolean ,
    roleText: string,
    status: string
  };

  private singleCourseDetails: {
    id: string ,
    title :string,
    courseCreator:string,
    courseDescription: string,
    discount: number,
    price:number ,
    tags: [string],
    status: string,
  };

  private boughtCourses = [];

  charactersChanged = new Subject<void>();
  cartUpdated = new Subject<void>();
  userDetailsUpdated = new Subject<void>();
  singleCourseDetailsUpdated = new Subject<void>();

  http: HttpClient;
  constructor(http: HttpClient ){
    this.http=http;
  }


  userId = 'IHfBFkON1qmh6aEeoieJ';
  onsolidatedApi =`https://us-central1-angularhu-83e85.cloudfunctions.net/webApi/api/v1/coursesWithStatus/user/${this.userId}`;


  fetchSingleCourse(courseId){
    this.http.get(`https://us-central1-angularhu-83e85.cloudfunctions.net/webApi/api/v1/course/${courseId}`)
    .pipe(
      map((responseData :  {
        id: string ,
        title :string,
        courseCreator:string,
        courseDescription: string,
        discount: number,
        price:number ,
        tags: [string],
        status: string
      }) => {

        // this.singleCourseDetails = responseData;
        return responseData;
      })
    )
    .subscribe(
      (data) =>{

        data.status = '';

        for(const course of this.allCourses){
          if(course.id == data.id){
            if(course.boughtState){
              data.status = 'addedToCart'
            }else if(course.wishlist){
              data.status = 'wishlisted'
            }
          }
        }

        console.log(data);
        this.singleCourseDetails = data;
        this.singleCourseDetailsUpdated.next();
      }
    );
  }

  getSingleCourse(){
    return this.singleCourseDetails;
  }


  fetchUser(){
    this.http.get(`https://us-central1-angularhu-83e85.cloudfunctions.net/webApi/api/v1/user/${this.userId}`)
    .pipe(
      map((responseData : {
        id: string ,
        displayName: string,
        firstName: string,
        lastName: string,
        aboutYourself :string,
        areasOfInterest:[number],
        experience: string,
        expertise: string,
        isProfessional:boolean ,
        roleText: string,
        status: string
      }) => {
        this.userDetails = responseData;
        return responseData;
      })
    )
    .subscribe(
      (data) =>{
        console.log(data);
        this.userDetails = data;
        this.userDetailsUpdated.next();
      }
    );
  }

  getUser(){
    return this.userDetails;
  }


  fetchCourses(){
    this.http.get(this.onsolidatedApi)
      .pipe(
        map((responseData : {[key: string]: {
          id: string ,
          title :string,
          courseCreator:string,
          courseDescription: string,
          discount: number,
          price:number ,
          tags: [string],
          status: string
        }} ) => {

          const dataArray:{
            id: string ,
            title :string,
            courseCreator:string,
            courseDescription: string,
            discount: number,
            price:number ,
            tags: [string],
            status: string
          }[] = [];
          for(const key in responseData){
            if(responseData.hasOwnProperty(key)){
              dataArray.push({...responseData[key]});
            }
          }

          console.log(dataArray);

          const recievedCourses = [];
          for (let key in dataArray) {
            let value = dataArray[key];

            let statusWishlist = false;
            let statusBoughtState = false;
            if(value.status == "addedToCart")
              statusBoughtState = true;
            else if(value.status == "wishlisted")
              statusWishlist = true;
            const uniqueCourse = {
              id: value.id ,
              title: value.title,
              course_creator: value.courseCreator,
              courseDescription: value.courseDescription,
              price: value.price,
              discount: Math.round(value.price*(100/(100-value.discount))),
              tags: value.tags,
              wishlist: statusWishlist,
              boughtState: statusBoughtState
            }
            recievedCourses.push(uniqueCourse);
            if(statusBoughtState==true){
              this.boughtCourses.push(uniqueCourse);
              this.totalCost+=value.price;
            }
          }
          return recievedCourses;
        })
      )
      .subscribe(
        (data) =>{
          console.log('This is final data:')
          console.log(data);
          this.allCourses = data;
          console.log('This is final data:')
          console.log(this.allCourses);
          this.cartUpdated.next();
        }
      );
  }

  updateUserDetails(user){
    this.http.put(`https://us-central1-angularhu-83e85.cloudfunctions.net/webApi/api/v1/user/${this.userId}`
    ,
      user
    ).subscribe(result => {
      alert('User Updated!');
      console.log(result);
    },
    error =>{
      console.log('Some Error Occured in User');
    });
  }

  changeStatusOfCourse_Wishlisted(course){
    const courseId = course.id;
    this.http.post(`https://us-central1-angularhu-83e85.cloudfunctions.net/webApi/api/v1/statusChange/wishlisted/user/${this.userId}`
    ,
      [courseId]

    ).subscribe(reponse => {
      this.addToWishlist(course);
      alert('Wishlist Updated!');
      console.log(reponse);
    },
    error =>{
      alert('Wishlist not Updated!\nSome Error Occured');
      console.log('Some Error Occured');
    });
  }

  changeStatusOfCourse_AddedtoCart(course){

    const courseId = course.id;
    this.http.post(`https://us-central1-angularhu-83e85.cloudfunctions.net/webApi/api/v1/statusChange/addedToCart/user/${this.userId}`
    ,
      [courseId]
    ).subscribe(reponse => {
      this.addToCart(course);
      alert('Cart Updated!');
      console.log(reponse);
    },
    error =>{
      alert('Cart not Updated!\nSome Error Occured');
      console.log('Some Error Occured')
    });
  }

  changeStatusOfCourse_DeleteWishList(course){

    const courseId = course.id;
    this.http.delete(
      `https://us-central1-angularhu-83e85.cloudfunctions.net/webApi/api/v1/deleteCourse/${courseId}/user/${this.userId}`
    ).subscribe(reponse => {
      this.removeFromWishlist(course);
      alert('Wishlist Updated!');
      console.log(reponse);
    },
    error =>{
      alert('Sorry!\nSome Error Occured');
      console.log('Some Error Occured')
    });
  }

  changeStatusOfCourse_DeleteAddedToCart(course){

    const courseId = course.id;
    this.http.delete(
      `https://us-central1-angularhu-83e85.cloudfunctions.net/webApi/api/v1/deleteCourse/${courseId}/user/${this.userId}`
    ).subscribe(reponse => {
      this.removeFromCart(course);
      alert('Cart Updated!');
      console.log(reponse);
    },
    error =>{
      alert('Sorry!\nSome Error Occured');
      console.log('Some Error Occured')
    });
  }

  getAllCourses(){
    return this.allCourses.slice();
  }
  getAllBoughtCourses(){
    return this.boughtCourses.slice();
  }
  getCost(){
    return this.totalCost;
  }
  getRecommendedCourses(){
    let recommendCourses = [];
    let recommendCount=2;
    for(let course of this.allCourses){
      if(recommendCount==0)
        break;
      if(course.boughtState==false){
        recommendCount--;
        recommendCourses.push(course);
      }
    }
    return recommendCourses;
  }
  getWishListCourses(){
    let wishlistCourses = [];
    for(let course of this.allCourses){
      if(course.wishlist==true){
        wishlistCourses.push(course);
      }
    }
    return wishlistCourses;
  }

  addToCart(course){
    const pos = this.allCourses.findIndex((item)=>{
      return item.id === course.id;
    })
    this.allCourses[pos].boughtState = true ;
    if(this.allCourses[pos].wishlist == true){
      this.allCourses[pos].wishlist =false;
      alert('As adding to Cart so removing from wishlist!');
    }

    let newCourse = this.allCourses[pos];
    this.boughtCourses.push(newCourse);

    this.totalCost+=course.price;

    this.charactersChanged.next();
    this.cartUpdated.next();
    this.singleCourseDetailsUpdated.next();

    console.log('SERVICE: Added to Cart')
  }

  removeFromCart(course){
    const pos = this.allCourses.findIndex((item)=>{
      return item.id === course.id;
    })

    const remIndex = this.boughtCourses.findIndex((item)=>{
      return item.id === course.id;
    });
    this.boughtCourses.splice(remIndex, 1);


    this.allCourses[pos].boughtState = false;
    this.allCourses[pos].wishlist = false;

    this.totalCost-=course.price;

    this.charactersChanged.next();
    this.cartUpdated.next();
    this.singleCourseDetailsUpdated.next();

    console.log('SERVICE: Removed from Cart')
  }


  addToWishlist(course){
    if(course.boughtState==true){
      this.removeFromCart(course);
      alert('As adding to Wishlist so removing from Cart!');
    }
    const pos = this.allCourses.findIndex((item)=>{
      return item.id === course.id;
    })
    this.allCourses[pos].wishlist = true;
    this.cartUpdated.next();
    this.singleCourseDetailsUpdated.next();
  }

  removeFromWishlist(course){
    const pos = this.allCourses.findIndex((item)=>{
      return item.id === course.id;
    })
    this.allCourses[pos].wishlist = false;
    this.cartUpdated.next();
    this.singleCourseDetailsUpdated.next();
  }
}


