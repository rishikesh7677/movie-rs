import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-checkout-dashboard',
  templateUrl: './checkout-dashboard.component.html',
  styleUrls: ['./checkout-dashboard.component.scss']
})
export class CheckoutDashboardComponent implements OnInit {
  allCourses = [];
  boughtCourses = [];
  recommendCourses = [];
  totalCost=0;

  courseService: CourseService;
  subscription;

  constructor(courseService: CourseService) {
    this.courseService = courseService;
  }

  ngOnInit(): void {
    this.allCourses = this.courseService.getAllCourses();
    this.boughtCourses = this.courseService.getAllBoughtCourses();
    this.totalCost =this.courseService.getCost();
    this.recommendCourses = this.courseService.getRecommendedCourses();

    this.subscription = this.courseService.cartUpdated.subscribe(
      ()=>{
        this.allCourses = this.courseService.getAllCourses();
        this.boughtCourses = this.courseService.getAllBoughtCourses();
        this.totalCost =this.courseService.getCost();
        this.recommendCourses =this.courseService.getRecommendedCourses();
      }
    );

  }

}
